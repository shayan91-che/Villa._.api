﻿using MagicVilla_VillaAPI.Models;

namespace MagicVilla_VillaAPI.Repository

{
    public interface IVillaRepository
    {
        Task<List<Villa>> GetAllAsync();
        Task<Villa> GetAsync(int id);
        Task CreateAsync(Villa entity);
        Task RemoveAsync(Villa entity);
        Task UpdateAsync(Villa entity);
        Task SaveAsync();
            
    }
}
