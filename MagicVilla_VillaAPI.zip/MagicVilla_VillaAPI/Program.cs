﻿using MagicVilla_VillaAPI.Data;
using MagicVilla_VillaAPI.Repository;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// --- بخش سرویس‌ها (Dependency Injection) ---

// ۱. ثبت دیتابیس با استفاده از کانکشن استرینگ موجود در appsettings
builder.Services.AddDbContext<ApplicationDbContext>(option => {
    option.UseSqlServer(builder.Configuration.GetConnectionString("DefaultSQLConnection"));
});

// ۲. ثبت ریپوزیتوری برای استفاده در کنترلرها
builder.Services.AddScoped<IVillaRepository, VillaRepository>();

// ۳. اضافه کردن قابلیت کنترلرها
builder.Services.AddControllers();

// ۴. تنظیمات CORS برای اینکه فرانت‌اِند بتونه به API وصل بشه
builder.Services.AddCors(options => {
    options.AddPolicy("AllowAll", policy => {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

// ۵. تنظیمات Swagger برای تست API
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// --- بخش Middleware (ترتیب این‌ها خیلی مهمه!) ---

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// فعال‌سازی فایل‌های استاتیک (مثل index.html در پوشه wwwroot)
app.UseStaticFiles();

app.UseHttpsRedirection();

// فعال‌سازی CORS (باید قبل از UseAuthorization باشه)
app.UseCors("AllowAll");

app.UseAuthorization();

app.MapControllers();

app.Run();
